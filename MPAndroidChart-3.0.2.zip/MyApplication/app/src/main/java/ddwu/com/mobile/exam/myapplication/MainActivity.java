package ddwu.com.mobile.exam.myapplication;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout contentLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        contentLayout = (LinearLayout)findViewById(R.id.contentLayout);
    }

    //접속/로그인 버튼 클릭 시 동작 (로그인화면을 뿌려줍니다)
    public void onLogIn(View v){
        //이전에 뿌려졌던 모든 뷰들을 삭제합니다.
        contentLayout.removeAllViews();

        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contentLayout.addView(inflater.inflate(R.layout.activity_login, null));

    }

    //재산현황 버튼 클릭 시 동작 (로그인화면을 뿌려줍니다)
    public void onProperty(View v){
        //이전에 뿌려졌던 모든 뷰들을 삭제합니다.
        contentLayout.removeAllViews();

        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contentLayout.addView(inflater.inflate(R.layout.activity_property, null));
    }

    //거래현황 버튼 클릭 시 동작 (로그인화면을 뿌려줍니다)
    public void onTransaction(View v){
        //이전에 뿌려졌던 모든 뷰들을 삭제합니다.
        contentLayout.removeAllViews();

        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contentLayout.addView(inflater.inflate(R.layout.activity_transaction, null));
    }

    //결산현황 버튼 클릭 시 동작 (로그인화면을 뿌려줍니다)
    public void onSettlement(View v){
        //이전에 뿌려졌던 모든 뷰들을 삭제합니다.
        contentLayout.removeAllViews();

        LayoutInflater inflater = (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        contentLayout.addView(inflater.inflate(R.layout.activity_settlement, null));
    }
}
